﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Collections;
using System.Web.UI.WebControls;

public partial class f2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["list"] != null)
            {
                ArrayList l = new ArrayList();
                l = (ArrayList)Session["list"];
                for(int i = 0; i < l.Count; i++)
                {
                    CheckBoxList1.Items.Add(l[i].ToString());
                }
            }
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        ArrayList c = new ArrayList();
        foreach(ListItem i in CheckBoxList1.Items)
        {
            if (i.Selected)
            {
                c.Add(i.Text);
            }
        }
        Session["hobby"] = c;
        Response.Redirect("./f3.aspx");

    }
}