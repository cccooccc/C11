﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Collections;
using System.Web.UI.WebControls;

public partial class f3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["hobby"] != null)
            {
                ArrayList l = new ArrayList();
                l= (ArrayList)Session["hobby"];
                for (int i = 0; i < l.Count; i++)
                {
                    Label lb1 = new Label();
                    lb1.Text = l[i].ToString() + "<br/>";
                    Form.Controls.Add(lb1);
                }
                }
        }
    }
}