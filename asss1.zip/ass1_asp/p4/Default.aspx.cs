﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            int[] numbers = new int[3];
            int result = numbers[4];
        }
        catch (IndexOutOfRangeException ex)
        {
            Label4.Text = "Code level Error Acuured: " + ex.Message;
            
        }
    }

    protected void Page_Error(object sender, EventArgs e)
    {
        Exception ex = Server.GetLastError();
        Response.Write("<script>alert('Please Enter Number Only')</script>");
        Context.ClearError();

    }


    protected void Button1_Click(object sender, EventArgs e)

    {
        int p1 = Convert.ToInt32(TextBox2.Text);
        int p2 = Convert.ToInt32(TextBox3.Text);
        if (p1==p2)
        {
            Label5.Text = "Password Matched Succesfully";
        }else
        {
            Label5.Text = "Opps! Password Does not Matched ";

        }
    }
}
