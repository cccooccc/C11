﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class p3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {

    }

    protected void Button1_Click1(object sender, EventArgs e)
    {
        string name = Request.Form["name"];
        string email = Request.Form["email"];
        string gender = Request.Form["gender"];
        string add = Request.Form["addr"];
        string pass = Request.Form["pass"];

        Response.Redirect("p5d.aspx?name=" + name + "&email=" + email + "&gender=" + gender + "&addr=" + add + "&pass=" + pass );
    }
}