﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class p5d : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string name = Request.QueryString["name"];
        string email = Request.QueryString["email"];
        string gender = Request.QueryString["gender"];
        string add = Request.QueryString["addr"];
        string pass = Request.QueryString["pass"];

        Label1.Text = name;
        Label2.Text = email;
        Label3.Text = gender;
        Label4.Text = add;
        Label5.Text = pass;
    }
}