﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
    //string data;
    protected void Button1_Click(object sender, EventArgs e)
    {

        string inps = stringinput.Text;
        int op = DropDownList1.SelectedIndex;

        if (op == 1)
        {
            string[] w = inps.Split(' ');
            for(int i = 0; i < w.Length; i++)
            {
                msg.Text += w[i] + "<br/>";
            }
          
           
        }else if (op == 2)
        {
            msg.Text = inps.Length.ToString();
        }
        else if (op == 3)
        {
            string rev = "";
            for (int i = inps.Length - 1; i >= 0; i--)
            {
                rev = rev + inps[i].ToString();
            }
            if (rev == inps)
            {
                msg.Text = "String is Planindrom";

            }
            else
            {
                msg.Text = "String is not Planindrom";
            }
        }
        else if (op == 4)
        {
            bool b = inps.All(char.IsLetter);
            if (b == true)
            {
                msg.Text = "This is Alphabetic";
            }else
            {
                msg.Text = "This is Non-Alphabetic";
            }
        }


       
    }
    
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }
}