﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ViewState["calculation"] = "";

        }
    }

    private void dis()
    {
        TextBox1.Text = ViewState["calculation"].ToString();
    }

    protected void num_click(object sender, EventArgs e)
    {
        Button button = (Button)sender;
        string d = button.Text;
        ViewState["calculation"] += d;
        dis();

    }

    protected void opadd_Click(object sender, EventArgs e)
    {
        Button button = (Button)sender;
        string op = button.Text;
        ViewState["calculation"] += " "+op+" ";
        dis();
    }
    private double evalcal(string cal)
    {
        string[] eles = cal.Split(' ');
        double result = 0;
        string curop = "+";
        for(int i = 0; i < eles.Length; i++)
        {
            string el = eles[i];
            if (i % 2 == 0)
            {
                double num = Convert.ToDouble(el);

                if (curop == "+")
                    result += num;
                else if (curop == "-")
                    result -= num;
                else if (curop == "*")
                    result *= num;
                else if (curop == "/")
                    result /= num;

            }else
            {
                curop = el;
            }
        }
        return result;
    }

    protected void eql_click(object sender, EventArgs e)
    {
        try
        {
            string calculation = ViewState["calculation"].ToString();
            double r = evalcal(calculation);
            ViewState["calculation"] = r.ToString();
            dis();
        }
        catch
        {
            ViewState["calculation"] = "0";
            dis();
        }
    }

    protected void ce_Click(object sender, EventArgs e)
    {
        ViewState["calculation"] = "";
        dis();
    }
}